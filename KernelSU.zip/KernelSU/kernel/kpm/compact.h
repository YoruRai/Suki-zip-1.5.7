#ifndef ___SUKISU_KPM_COMPACT_H
#define ___SUKISU_KPM_COMPACT_H

unsigned long sukisu_compact_find_symbol(const char* name);

#endif